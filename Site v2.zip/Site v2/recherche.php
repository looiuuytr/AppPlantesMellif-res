<?php 

require_once __DIR__."/modele/modele.php";

class recherche {
	private $modele;
	
	
	function __construct(){
		
		$this->modele=new Modele();
	
}
	function getAll(){
		$test=$this->modele->getAll();
		print_r($test);
}
	
	
}


?>
