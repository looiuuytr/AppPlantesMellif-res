

<?php




// Classe generale de definition d'exception
class MonException extends Exception{
  private $chaine;
  public function __construct($chaine){
    $this->chaine=$chaine;
  }

  public function afficher(){
    return $this->chaine;
  }

}


// Exception relative à un probleme de connexion
class ConnexionException extends MonException{
}

// Exception relative à un probleme d'accès à une table
class TableAccesException extends MonException{
}


// Classe qui gère les accès à la base de données

class Modele{
private $connexion;

// Constructeur de la classe
// remplacer X par les informations qui vous concernent

  public function __construct(){
   try{
      /*$chaine="mysql:host=localhost;dbname=E155000D";
      $this->connexion = new PDO($chaine,"E155000D","E155000D");*/
      $chaine="mysql:host=localhost;dbname=info2-2016-melli-db";
      $this->connexion = new PDO($chaine,"info2-2016-melli","plantmelli");
      $this->connexion->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
     }
    catch(PDOException $e){
      $exception=new ConnexionException("problème de connection à la base");
      throw $exception;
    }
  }




// A développer
// méthode qui permet de se deconnecter de la base
public function deconnexion(){


   $this->connexion=null;
}


  public function levenshtein($input){

    try{
        $requete= 'select nomFr from PLANT_MELLI;';
        $statement=$this->connexion->query($requete);

        while ($donnees = $statement->fetch())
        {
            // tableau de mots à vérifier
          $words[] = $donnees['nomFr'];
        }



    // aucune distance de trouvée pour le moment
    $shortest = -1;

    // boucle sur les des mots pour trouver le plus près
    foreach ($words as $word) {

      // calcule la distance avec le mot mis en entrée,
      // et le mot courant
      $lev = levenshtein($input, $word);

      // cherche une correspondance exacte
      if ($lev == 0) {

        // le mot le plus près est celui-ci (correspondance exacte)
        $closest = $word;
        $shortest = 0;

        // on sort de la boucle ; nous avons trouvé une correspondance exacte
        break;
      }

      // Si la distance est plus petite que la prochaine distance trouvée
      // OU, si le prochain mot le plus près n'a pas encore été trouvé
      if ($lev <= $shortest || $shortest < 0) {
        // définition du mot le plus près ainsi que la distance
        $closest  = $word;
        $shortest = $lev;
      }
    }

    echo "Mot entré : $input"."\n";
    if ($shortest == 0) {
      echo "Correspondance exacte trouvée : $closest\n";
    } else {
      echo "Vous voulez dire : $closest ?\n";
    }


  }


  catch(PDOException $e){
    $exception=new TableAccesException($e);
    return $exception;
  }
  }
}




?>
