<?php
//header('Content-Type: text/html; charset=iso-8859-1');
header("Content-type: text/html; charset=utf-8");
require("../modele/test simon.php");//import


  try{


      $modele=new Modele();
      $modele->afficherPlante($modele->levenshteinLat($_POST["planteRech"]));

  }

  catch (ConnexionException $e){
  echo "problème de connexion";
  }
  catch (TableAccesException $e){
  echo "problème de d'acces à une table";
  }


?>
