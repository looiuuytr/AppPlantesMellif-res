<form method="post" action="test test simon.php">


  <p>
     <label for="nom">Nom : </label>
         <input type="text" name="planteRech" methode="Post" />
  </p>


       <input type="submit" value="Envoyer" />
</form>
