<?php




// Classe generale de definition d'exception
class MonException extends Exception{
  private $chaine;
  public function __construct($chaine){
    $this->chaine=$chaine;
  }

  public function afficher(){
    return $this->chaine;
  }

}


// Exception relative à un probleme de connexion
class ConnexionException extends MonException{
}

// Exception relative à un probleme d'accès à une table
class TableAccesException extends MonException{
}


// Classe qui gère les accès à la base de données

class Modele{
private $connexion;

// Constructeur de la classe
// remplacer X par les informations qui vous concernent

  public function __construct(){
   try{
      $chaine="mysql:host=localhost;dbname=info2-2016-melli-db";
      $this->connexion = new PDO($chaine,"info2-2016-melli","plantmelli");
      $this->connexion->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
     }
    catch(PDOException $e){
      $exception=new ConnexionException("problème de connection à la base");
      throw $exception;
    }
  }




// A développer
// méthode qui permet de se deconnecter de la base
public function deconnexion(){
   $this->connexion=null;
}


//A développer
// utiliser une requête classique
// méthode qui permet de récupérer les pseudos dans la table pseudo
// post-condition:
//retourne un tableau à une dimension qui contient les pseudos.
// si un problème est rencontré, une exception de type TableAccesException est levée

public function getAll(){
 try{

$statement=$this->connexion->query("SELECT * from PLANT_MELLI;");

$result=$statement->fetch();

return($result);
}
catch(PDOException $e){
    throw new TableAccesException("problème avec la table PLANT_MELLI");
  }
}

public function levenshteinFr($input){
  try{


      $requete= "select nomFr from PLANT_MELLI;";
      $statement=$this->connexion->query($requete);
      while ($donnees = $statement->fetch())
      {
          // tableau de mots à vérifier
        $words[] = $donnees['nomFr'];
      }



  // aucune distance de trouvée pour le moment
  $shortest = -1;

  // boucle sur les des mots pour trouver le plus près
  foreach ($words as $word) {

    // calcule la distance avec le mot mis en entrée,
    // et le mot courant
    $lev = levenshtein($input, $word);

    // cherche une correspondance exacte
    if ($lev == 0) {

      // le mot le plus près est celui-ci (correspondance exacte)
      $closest = $word;
      $shortest = 0;

      // on sort de la boucle ; nous avons trouvé une correspondance exacte
      break;
    }

    // Si la distance est plus petite que la prochaine distance trouvée
    // OU, si le prochain mot le plus près n'a pas encore été trouvé
    if ($lev <= $shortest || $shortest < 0) {
      // définition du mot le plus près ainsi que la distance
      $closest  = $word;
      $shortest = $lev;
    }

  }
  echo "Mot entré : $input"."\n";
  if ($shortest == 0) {
    echo "Correspondance exacte trouvée : $closest\n";
  } else {
    echo "Vous voulez dire : $closest ?\n";
  }


}


catch(PDOException $e){
  $exception=new TableAccesException($e);
  echo $e->getMessage();
  return $exception;
}
}


public function levenshteinLat($input){
  try{


      $requete= "select nomLat from PLANT_MELLI;";
      $statement=$this->connexion->query($requete);
      while ($donnees = $statement->fetch())
      {
          // tableau de mots à vérifier
        $words[] = $donnees['nomLat'];
      }



  // aucune distance de trouvée pour le moment
  $shortest = -1;

  // boucle sur les des mots pour trouver le plus près
  foreach ($words as $word) {

    // calcule la distance avec le mot mis en entrée,
    // et le mot courant
    $lev = levenshtein($input, $word);

    // cherche une correspondance exacte
    if ($lev == 0) {

      // le mot le plus près est celui-ci (correspondance exacte)
      $closest = $word;
      $shortest = 0;

      // on sort de la boucle ; nous avons trouvé une correspondance exacte
      break;
    }

    // Si la distance est plus petite que la prochaine distance trouvée
    // OU, si le prochain mot le plus près n'a pas encore été trouvé
    if ($lev <= $shortest || $shortest < 0) {
      // définition du mot le plus près ainsi que la distance
      $closest  = $word;
      $shortest = $lev;
    }

  }
  echo "Mot entré : $input"."\n";
  if ($shortest == 0) {
    echo "Correspondance exacte trouvée : $closest\n";
  } else {
    echo "Vous voulez dire : $closest ?\n";
  }


}


catch(PDOException $e){
  $exception=new TableAccesException($e);
  echo $e->getMessage();
  return $exception;
}
}


//A développer
// utiliser une requête préparée
//vérifie qu'un pseudo existe dans la table pseudonyme
// post-condition retourne vrai si le pseudo existe sinon faux
// si un problème est rencontré, une exception de type TableAccesException est levée
/*
public function exists($pseudo){
try{
	$statement = $this->connexion->prepare("select id from pseudonyme where pseudo=?;");
	$statement->bindParam(1, $pseudoParam);
	$pseudoParam=$pseudo;
	$statement->execute();
	$result=$statement->fetch(PDO::FETCH_ASSOC);

	if ($result["id"]!=NUll){
	return true;
	}
	else{
	return false;
	}
}
catch(PDOException $e){
    $this->deconnexion();
    throw new TableAccesException("problème avec la table pseudonyme");
    }
}



//A développer
// utiliser uen requête préparée
// ajoute un message sur le salon => pseudonyme + message
// precondition: le pseudo existe dans la table pseudonyme
// post-condition: le message est ajouté dans la table salon
// si un problème est rencontré, une exception de type TableAccesException est levée

public function majSalon($pseudo,$message){
      try{

      $statement = $this->connexion->prepare("select id from pseudonyme where pseudo=?;");
	$statement->bindParam(1, $pseudoParam);
	$pseudoParam=$pseudo;
	$statement->execute();
	$result=$statement->fetch(PDO::FETCH_ASSOC);
	$statement = $this->connexion->prepare("INSERT INTO salon (idpseudo, message) VALUES (?,?);");
	$statement->bindParam(1, $result['id']);
	$statement->bindParam(2, $message);
	$statement->execute();

	}
    catch(PDOException $e){
    $this->deconnexion();
    throw new TableAccesException("problème avec la table salon");
    }
}

*/

public function getByNomFr(){

      try{

$statement=$this->connexion->query("SELECT * FROM `PLANT_MELLI` ORDER BY nomFr");

	return($statement->fetchAll(PDO::FETCH_ASSOC));

    }
  catch(PDOException $e){
    $this->deconnexion();
    throw new TableAccesException("problème avec la table salon");
  }
}




public function afficherPlante($input){
  try{

    $stmt= $this->connexion->prepare("SELECT * FROM PLANT_MELLI WHERE nomLat=?");

    $stmt->execute(array($input));

    while ($donnees = $stmt->fetch(PDO::FETCH_ASSOC))
{
?>
    <p>
    NomLat : <?php echo $donnees['nomLat']; ?><br/>
    NomFr : <?php echo $donnees['nomFr']; ?><br/>
    Type : <?php echo $donnees['Type']; ?><br/>
    Famille : <?php echo $donnees['Famille']; ?><br/>
    Moyenne_kg/ha : <?php echo $donnees['Moyenne_kg/ha']; ?><br/>
    inter_apicole : <?php echo $donnees['inter_apicole']; ?><br/>
    Exposition : <?php echo $donnees['Exposition']; ?><br/>
    Nectarifère : <?php echo $donnees['Nectarifere']; ?><br/>
    Pollinifère : <?php echo $donnees['Pollinifere']; ?><br/>
    debut_Floraison : <?php echo $donnees['debut_Floraison']; ?><br/>
    fin_Floraison : <?php echo $donnees['fin_Floraison']; ?><br/>

    </p>
<?php
}
}
catch(PDOException $e){
  echo $e->getMessage();

  $exception=new TableAccesException($e);
  return $exception;
}

}
}
?>
