<?php
require_once "recherche.php";

$r=new Recherche();

$r->getAll();

?>