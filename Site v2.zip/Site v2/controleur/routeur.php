<?php




class Routeur {





  public function __construct() {
    $this->ctrlAuthentification= new ControleurAuthentification();
    $this->ctrlMessage=new ControleurMessage();
  }

  // Traite une requête entrante
  public function routerRequete() {



    if (isset($_POST["message"])){
      $this->ctrlMessage->ajoutM($_SESSION['Spseudo'],$_POST["message"]);
      $this->ctrlMessage->afficheM();
    }

    else  {

          if ($this->ctrlAuthentification->estvalide()){
              $_SESSION['Spseudo'] = $_POST["pseudo"];
              $this->ctrlMessage->afficheM();
          }
          else {
              unset($_SESSION['Spseudo']);
              $this->ctrlAuthentification->accueil();
          }
      }


}

}




?>
