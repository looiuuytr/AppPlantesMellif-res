<?php

require_once __DIR__."/../modele/modele.php";

class ControleurAuthentification{


private $modele;


function __construct(){

$this->modele=new Modele();

}



function estvalide(){
  if (!isset($_POST["pseudo"]) || !isset($_POST["mdp"]  )){
    return false;
  }

  $pseudo=$_POST["pseudo"];
  if ($this->modele->exists($pseudo)){
    $mdpPropose=$_POST["mdp"];
    $mdpBd=$this->modele->getMdp($pseudo);

    return crypt($mdpPropose, $mdpBd)== $mdpBd;

  }
  else return false;


}



}
